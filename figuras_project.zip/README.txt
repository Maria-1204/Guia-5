
Proyecto: Figuras
Estructura:
- src/figuras/*.java
- src/presentacion/Main.java

Compilación:
Desde el directorio src:
  javac figuras/*.java presentacion/*.java
  java presentacion.Main

Este paquete implementa las clases solicitadas en la guía: Figura (abstracta), Punto, Triangulo,
Cuadrilatero y Cuadrado, además del paquete presentacion con la clase Main que crea las figuras
solicitadas, imprime su area y perimetro.

Archivo generado: figuras_project.zip
